// import { MdOutlineDashboard } from "react-icons/md";
// import { NavListType } from "./index";

// export const MenuItems: NavListType[] = [
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
//   {
//     title: "Order List",
//     path: "/dashboard/orders",
//     icon: <MdOutlineDashboard />
//   },
// ];
