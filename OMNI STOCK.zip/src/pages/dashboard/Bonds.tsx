
const Bonds = () => {
  return (
    <div>Bonds</div>
  )
}

export default Bonds