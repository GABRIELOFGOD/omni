
const Traders = () => {
  return (
    <div>Traders</div>
  )
}

export default Traders