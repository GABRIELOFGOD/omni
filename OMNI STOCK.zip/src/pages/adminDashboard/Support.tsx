
import { useEffect } from "react";
import useAuth from "../../hooks/useAuth";

const Support = () => {
  const { getUserData, userData } = useAuth();

  useEffect(() => {
    getUserData();
  },[]);
  
  return (
    <div className="flex flex-col gap-10 text-black">
      <p className="text-xl">Welcome to support <b>{userData?.firstName}</b></p>
      <div className="w-full md:w-[300px] bg-white p-3 rounded-md">
        <p className="font-bold text-lg">GPTCOIN PRICE</p>
        <div className="flex flex-col gap-3 py-5">
          <input className="w-full outline-none bg-light h-12 rounded-md px-3" type="number" />
          <button
            className={`w-full h-12 justify-center items-center bg-primary hover:bg-neutral-900 duration-200 font-semibold text-white rounded-md`}
          >
            Update ROI
          </button>
        </div>
      </div>
    </div>
  )
}

export default Support