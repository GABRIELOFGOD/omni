
const Investments = () => {
  return (
    <div>
      Investments
    </div>
  )
}

export default Investments